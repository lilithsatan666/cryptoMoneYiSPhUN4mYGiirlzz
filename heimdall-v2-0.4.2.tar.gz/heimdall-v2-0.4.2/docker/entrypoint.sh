#!/usr/bin/env sh

exec heimdalld --home="$HEIMDALL_DIR" "$@"
