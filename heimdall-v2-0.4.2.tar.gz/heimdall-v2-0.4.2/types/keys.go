package types

const (
	// DefaultLogIndexUnit is the default tx hash + log index unit (used to calculate sequence ID)
	DefaultLogIndexUnit = 100000
)
